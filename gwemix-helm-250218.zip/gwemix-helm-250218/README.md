# 2025-02-18 jack
WEMIX3.0 GWEMIX : helm templates
